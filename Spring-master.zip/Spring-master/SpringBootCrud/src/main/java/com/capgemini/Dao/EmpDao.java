package com.capgemini.Dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.bean.Employee;

@Service
public class EmpDao {

	static HashMap<Integer, Employee> al = new HashMap<>();
	static {
		al.put(101, new Employee(101, "Rahul", "Manager", 20000));
		al.put(102, new Employee(102, "Arvind", "System-engineer", 50000));
		al.put(103, new Employee(103, "Yanshu", "Consultant", 30000));

	}

	public Employee save(Employee e) {
		al.put(e.getEmpId(), e);
		return e;
	}

	public Employee display(int empId) {
		if (al.containsKey(empId)) {
			return al.get(empId);
		}
		return null;
	}

	public void delete(int empId) {

		al.remove(empId);

	}

	public Employee update(Employee e) {
		al.put(e.getEmpId(), e);
		return e;
	}

	public List<Employee> getAllEmployees() {
		Collection<Employee> c = al.values();
		List<Employee> list = new ArrayList<Employee>();
		list.addAll(c);
		return list;
	}
}
