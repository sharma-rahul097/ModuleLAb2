package com.capgemini.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Util.UserRepository;
import com.capgemini.bean.Employee;

@Service
public class EmpDao {

	@Autowired
	UserRepository userRepo;
	
	public Employee save(Employee e) {
	 
		return userRepo.save(e);
	}

	public Optional<Employee> display(int empId) {
		return userRepo.findById(empId);
	}

	public void delete(int empId) {

		userRepo.deleteById(empId);

	}

	public Employee update(Employee e) {
		return userRepo.save(e);
	}

	public List<Employee> getAllEmployees() {
		return (List<Employee>) userRepo.findAll();
	}
}
