package com.capgemini.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Dao.EmpDao;
import com.capgemini.bean.Employee;

@RestController
public class MyControllerClass {

	@Autowired
	EmpDao empDao;

	@GetMapping("/empAll")
	public List<Employee> getAllEmployee() {
		return (List<Employee>) empDao.getAllEmployees();

	}

	@PostMapping("/empAdd")
	//@ResponseBody
	public Employee addEmployee(@RequestBody Employee emp) {
		return empDao.save(emp);
	}

	@RequestMapping(value = "/empDetail/{empNo}", method = RequestMethod.GET)
	@ResponseBody
	public Optional<Employee> getEmployee(@PathVariable int empNo) {
		return empDao.display(empNo);
	}
	
	@RequestMapping(value = "/empDelete/{id}", method = RequestMethod.GET)
	public void deleteEmployee(@PathVariable int id) {
		empDao.delete(id);
	}
}
