package com.capgemini.Util;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bean.Employee;

@Repository
public interface UserRepository extends CrudRepository<Employee, Integer> {

}
