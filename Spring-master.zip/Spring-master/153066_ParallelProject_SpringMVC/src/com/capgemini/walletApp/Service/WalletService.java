package com.capgemini.walletApp.Service;

import java.math.BigDecimal;

import com.capgemini.walletApp.Exception.InsufficientBalanceException;
import com.capgemini.walletApp.Exception.InvalidInputException;
import com.capgemini.walletApp.Exception.MobileNumberAlredyRegisteredException;
import com.capgemini.walletApp.Exception.MobileNumberNotFoundException;
import com.capgemini.walletApp.beans.Customer;

public interface WalletService {
	public Customer createAccount(Customer customer) throws MobileNumberAlredyRegisteredException;

	public Customer showBalance(String mobileno) throws MobileNumberNotFoundException;

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount)
			throws InvalidInputException, InsufficientBalanceException;

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException;

	public Customer withdrawAmount(String mobileNo, BigDecimal amount)
			throws InvalidInputException, InsufficientBalanceException;

}
