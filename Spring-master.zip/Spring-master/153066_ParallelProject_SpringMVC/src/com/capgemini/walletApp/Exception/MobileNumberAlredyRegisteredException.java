package com.capgemini.walletApp.Exception;

import java.util.Arrays;

public class MobileNumberAlredyRegisteredException extends Exception {

	@Override
	public String toString() {
		return "Mobile Number Alredy Exist ";
	}

	
}
