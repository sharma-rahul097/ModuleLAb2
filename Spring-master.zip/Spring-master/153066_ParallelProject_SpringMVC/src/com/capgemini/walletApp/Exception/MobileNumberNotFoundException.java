package com.capgemini.walletApp.Exception;

import java.util.Arrays;

public class MobileNumberNotFoundException extends Exception {

	@Override
	public String toString() {
		return "Mobile Number NotFound Exception";
	}
	
	

}
