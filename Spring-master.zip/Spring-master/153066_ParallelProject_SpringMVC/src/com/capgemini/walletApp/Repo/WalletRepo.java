package com.capgemini.walletApp.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.walletApp.beans.Customer;

public interface WalletRepo extends JpaRepository<Customer, String> {
		
}
