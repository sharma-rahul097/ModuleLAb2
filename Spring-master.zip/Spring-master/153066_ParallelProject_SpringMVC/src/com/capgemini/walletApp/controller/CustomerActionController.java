package com.capgemini.walletApp.controller;

import java.math.BigDecimal;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.walletApp.Exception.InsufficientBalanceException;
import com.capgemini.walletApp.Exception.InvalidInputException;
import com.capgemini.walletApp.Exception.MobileNumberAlredyRegisteredException;
import com.capgemini.walletApp.Exception.MobileNumberNotFoundException;
import com.capgemini.walletApp.Service.WalletService;
import com.capgemini.walletApp.beans.Customer;

@Controller
public class CustomerActionController {
	@Autowired
	WalletService service;

	@RequestMapping(value = "/registerCustomer")
	public ModelAndView registerCustomer(@Valid @ModelAttribute("customer") Customer customer, BindingResult result) {
		
		try {
			customer = service.createAccount(customer);
		} catch (MobileNumberAlredyRegisteredException error) {
			return new ModelAndView("Error", "message", error);
		}
		return new ModelAndView("WelcomePage", "customer", customer);
	}

	@RequestMapping(value = "/viewwallet")
	public ModelAndView viewCustomer(@RequestParam("mobileNo") String mobileNo) {
		Customer customer = null;
		try {
			customer = service.showBalance(mobileNo);
		} catch (MobileNumberNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("ViewWallet", "customer", customer);
	}

	@RequestMapping(value = "/deposit")
	public String getdeposit() {
		return "Deposit";
	}

	@RequestMapping(value = "/depositmoney", method = RequestMethod.GET)
	public ModelAndView deposit(HttpServletRequest request) {
		Customer customer = null;
		String mob = request.getParameter("mobileNo");
		String bal = request.getParameter("balance");

		try {
			customer = service.depositAmount(mob, new BigDecimal(bal));
		} catch (InvalidInputException e) {
			e.printStackTrace();
		}

		return new ModelAndView("DepositSucess", "customer", customer);
	}

	@RequestMapping(value = "/withdraw")
	public String getwithdraw() {
		return "WithDraw";
	}

	@RequestMapping(value = "/withdrawmoney", method = RequestMethod.GET)
	public ModelAndView draw(HttpServletRequest request) {
		Customer customer = null;
		String mob = request.getParameter("mobileNo");
		String bal = request.getParameter("balance");

		try {
			customer = service.withdrawAmount(mob, new BigDecimal(bal));
		} catch (InvalidInputException | InsufficientBalanceException e) {
			e.printStackTrace();
		}

		return new ModelAndView("WithDrawSucess", "customer", customer);
	}

	@RequestMapping(value = "/fundtransfer")
	public String Funds() {
		return "FundTransfer";
	}

	@RequestMapping(value = "/fundtransfered", method = RequestMethod.GET)
	public ModelAndView fundTransfer(HttpServletRequest request) {
		Customer customer = null;
		String source = request.getParameter("sourceMobileNo");
		String target = request.getParameter("destinationMobileNo");
		String amount = request.getParameter("balance");

		try {
			customer = service.fundTransfer(source, target, new BigDecimal(amount));
		} catch (InvalidInputException | InsufficientBalanceException e) {

			e.printStackTrace();
		}
		return new ModelAndView("FundsTransfered", "customer", customer);
	}

	@RequestMapping(value = "/MainApp")
	public String getMainApp() {
		return "MainApp";
	}

}
