package com.capgemini.walletApp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.walletApp.beans.Customer;

@Controller
public class URIController {
	@RequestMapping(value="/")
	public String getIndexPage() {
		return "index";
	}
	@RequestMapping(value="/login")
	public String getLoginPage() {
		return "Login";
	}
	
	@RequestMapping(value="/signin")
	public String getSigninPage() {
		return "SignIn";
	}
	@ModelAttribute("customer")
	public Customer getCustomer() {
		return new Customer();
	}
	

}
