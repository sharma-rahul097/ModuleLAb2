package com.cg.repository;

import com.cg.bean.Merchant;
import com.cg.bean.Orders;
import com.cg.bean.Product;

public interface ICapstoreDao 
{
	public Product addProduct(Product product);
	public Product deleteProduct(Product product);
	public Orders checkOrderDetails(Orders order);
	public String changePassword(Merchant merchant);
}
