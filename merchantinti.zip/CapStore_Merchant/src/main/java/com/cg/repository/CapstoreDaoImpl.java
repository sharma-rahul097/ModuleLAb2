package com.cg.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.bean.Merchant;
import com.cg.bean.Orders;
import com.cg.bean.Product;


@Repository
public class CapstoreDaoImpl implements ICapstoreDao
{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Product addProduct(Product product) 
	{
		em.persist(product);
		return product;
	}

	@Override
	public Product deleteProduct(Product product) 
	{
		Product product1 = em.find(Product.class, product.getProdId());
		em.remove(product1);
		return product1;
	}

	@Override
	public Orders checkOrderDetails(Orders order) 
	{
		Orders order1 = em.find(Orders.class, order.getOrderId());
		return order1;
	}

	@Override
	public String changePassword(Merchant merchant) {
		
		return null;
	}

	

	
	
	
	
}
