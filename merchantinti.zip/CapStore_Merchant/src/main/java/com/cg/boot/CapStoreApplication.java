package com.cg.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


@SpringBootApplication(scanBasePackages={"com.cg"})
@EntityScan(basePackages="com.cg.bean")
public class CapStoreApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(CapStoreApplication.class, args);
	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CapStoreApplication.class);
	}
}
