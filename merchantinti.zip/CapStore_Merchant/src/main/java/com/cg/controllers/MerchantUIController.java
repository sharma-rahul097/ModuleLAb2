package com.cg.controllers;

import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.Product;

@Controller
public class MerchantUIController 
{
	

	@RequestMapping(value="/")
	public String getHomePage()
	{
		return "merchant_home";
		
	}
	@RequestMapping(value="/merchant_add_product")
	public String getaddCategoryPage()
	{
		return "merchant_add_product";
		
	}
	@RequestMapping(value="/merchant_change_password")
	public String getaddMerchantPage()
	{
		return "merchant_change_password";
		
	}
	@RequestMapping(value="/merchant_check_order_details")
	public String getCustomersPage()
	{
		return "merchant_check_order_details";
		
	}
	@RequestMapping(value="/merchant_delete_product")
	public String getMerchantPage()
	{
		return "merchant_delete_product";
		
	}
	@RequestMapping(value="/Success")
	public String successRegister(@ModelAttribute("product") Product product)
	{
		Random random=new Random();
		String prodId="P#"+Integer.toString(random.nextInt(100));
		product.setProdId(prodId);
		System.out.println(product);
		return "Success";
		
	}
	
	
}
