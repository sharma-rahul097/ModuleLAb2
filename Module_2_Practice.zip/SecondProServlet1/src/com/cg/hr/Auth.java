package com.cg.hr;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Authenticate")
public class Auth extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//pick up Qery String data (get)
		//pick up form Data (post)
		String username = request.getParameter("Username");
		String pwd = request.getParameter("password");
		
		if(username.equals("Rs") && pwd.equals("abzx8888"))
		{
			String fullName = "Rahul Sharma";
			
			// request Scope
			request.setAttribute("fullName",fullName);
			RequestDispatcher rd = request.getRequestDispatcher("Hello.jsp");
			rd.forward(request, response);
		}
		else
		{
			request.setAttribute("message", "Authentication error pls do again");
			RequestDispatcher rd = request.getRequestDispatcher("Login.jsp");
			rd.forward(request, response);
		}
//		System.out.println("User name:" + username + "\nPassword:"+ pwd);
	}

}
