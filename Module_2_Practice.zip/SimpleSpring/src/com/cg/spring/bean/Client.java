package com.cg.spring.bean;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {

	public static void main(String[] args) {
		
		Resource res = new ClassPathResource("beans.xml");
		XmlBeanFactory fact = new XmlBeanFactory(res);
		
		Employee e1 = (Employee) fact.getBean("e1");
		Employee e2 = (Employee) fact.getBean("e2");
	
		System.out.println(e1);
		System.out.println(e2);
	}
}
